//amir hossein salajegheh - 40223039
#include <stdio.h>
 
typedef struct time 
{
    int min;
    int sec;
}TIME;

typedef struct runner
{
    char firstname[30];
    char lastname[30];
    char ID[20];
    TIME runningtime;
    TIME *record;
}RUNNER; 

int main ()
{

    int number;       
    printf("enter the numbers of runners\n");
    scanf("%d",&number);
    TIME t;

    RUNNER inf[number];
    for (int i = 0; i < number; i++)
    {
        inf[i].record=&t;
        printf("enter information of runner%d:\n",i+1);
        scanf("%s%s%s",inf[i].firstname,inf[i].lastname,inf[i].ID);
        scanf("%d%d",&inf[i].record->min,&inf[i].record->sec);
        scanf("%d%d",&inf[i].runningtime.min,&inf[i].runningtime.sec);
    }

    int bestrecordmin , bestrecordsec;
    bestrecordmin=inf[0].record->min;
    bestrecordsec=inf[0].record->sec;

    for(int i=0; i<number; i++)
    {
        if(bestrecordmin > inf[i].record->min )
        {
                bestrecordmin=inf[i].record->min;
                bestrecordsec=inf[i].record->sec;
        }
        else if (bestrecordmin == inf[i].record->min)
        {
            if (bestrecordsec > inf[i].record->sec)
            {
                bestrecordmin=inf[i].record->min;
                bestrecordsec=inf[i].record->sec;
            }
        }
    }

    int winnertime1 ,winnertime2;
    winnertime1=inf[0].runningtime.min;
    winnertime2=inf[0].runningtime.sec;
    for(int i=0; i<number;i++)
    {
        if(winnertime1 > inf[i].runningtime.min)
        {
            winnertime1=inf[i].runningtime.min;
            winnertime2=inf[i].runningtime.sec;
        }
        else if (winnertime1 == inf[i].runningtime.min)
        {
            if(winnertime2 > inf[i].runningtime.sec)
            {
                winnertime1=inf[i].runningtime.min;
                winnertime2=inf[i].runningtime.sec;
            }
        }
    }

    for(int i=0; i<number; i++)
    {
        if(winnertime1==inf[i].runningtime.min && winnertime2==inf[i].runningtime.sec)
        {
            printf("the winner is %s %s\n",inf[i].firstname,inf[i].lastname);
            if(winnertime1 < inf[i].record->min || (winnertime2 < inf[i].record->sec && winnertime1 == inf[i].record->min))
            {
                printf("the running time of winner could  break its record\n");
            }
            else
            {
                printf("the running time of winner couldn't  break its record\n");
            }
            if(winnertime1 < bestrecordmin || (winnertime2 < bestrecordsec && winnertime1 == bestrecordmin))
            {
                printf("the record was broken by winner\n");
            }
            else
            {
                printf("the record wasn't broken by winner\n");
            }
        }
    }

    RUNNER temp[number];
    for(int i=0; i<number-1; i++)
    {
        for(int j=i; j<number-1; j++)
        {
            if(inf[j].runningtime.min > inf[j+1].runningtime.min ||  
            (inf[j].runningtime.min == inf[j+1].runningtime.min && inf[i].runningtime.sec > inf[i+1].runningtime.sec))
            {
                    temp[j]=inf[j+1];
                    inf[j+1]=inf[j];
                    inf[j]=temp[j];
            }
        }
    }

    printf("%-20s %-20s %-15s %-30s %-25s %-30s %-25s\n", "first name", "last name", "ID", "record minutes",
     "record second" ,"running time minutes", "running time second");
    for(int i=0; i<number; i++)
    {
        printf("%-20s %-20s %-15s %-30d %-25d %-30d %-25d\n",inf[i].firstname,inf[i].lastname,inf[i].ID,inf[i].record->min,
        inf[i].record->sec,inf[i].runningtime.min,inf[i].runningtime.sec);
    }
}